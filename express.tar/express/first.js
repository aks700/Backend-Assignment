let express=require('express')
let app=express()

//endPoints
// app.get('/home',(req,res)=>{
//    res.send("Testing the response")
// })

//local is cartify.js, express is 3rd party, inbuilt is http

app.use('/cartify',require('./cartify.js'))

app.listen(3000,()=>console.log("Server Started"))