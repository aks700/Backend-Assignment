
const express=require('express')
const router=express.Router()


router.route('/stud/:userName').get((req,res)=>{
    const userName=req.params.userName;
    if(userName==='Daniel')
    {
        res.json("Name is Daniel")
    }
    else{
        res.json("Name is not Daniel")
    }
})


router.route('/prof/:userName').post((req,res)=>{
    res.json(`Welcome to this page ${req.params.userName}`)
})


router.route('/emp').post((req,res)=>{
    res.json('Hey you are now here')
})

module.exports=router