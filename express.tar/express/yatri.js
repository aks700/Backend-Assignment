const express=require('express')

const router=express.Router()
//const {router}=


router.use('/yatri/profile',require('./people.js'))

module.exports= router

// const express = require('express');
// const router = express.Router();


// router.get('/yatri/profile/stud/:userName', (req, res) => {
//     const userName = req.params.userName;
//     if (userName === 'Daniel') {
//         res.json("Name is Daniel");
//     } else {
//         res.json("Name is not Daniel");
//     }
// });


// router.post('/yatri/profile/prof/:userName', (req, res) => {
//     res.json(`Welcome to this page ${req.params.userName}`);
// });


// router.post('/yatri/profile/emp', (req, res) => {
//     res.json('Hey you are now here');
// });

// module.exports = {
//     yatri: router
// };
