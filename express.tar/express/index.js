const express=require('express')
const app=express()
const router=require('./yatri')
// const {yatri}=require('./yatri')



app.use('/student',router)
app.use('/professor',router)
app.use('/employee',router)
// app.use('/student',yatri)
// app.use('/professor',yatri)
// app.use('/employee',yatri)


app.listen(3000,()=>console.log('Server Started'))